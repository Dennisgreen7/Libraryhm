﻿
namespace LaiblaryHM
{
    partial class ClientControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataPanel = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.valuePannel = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.idBox = new System.Windows.Forms.TextBox();
            this.lnBox = new System.Windows.Forms.TextBox();
            this.idnBox = new System.Windows.Forms.TextBox();
            this.phoneBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.fnBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonsPanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.bDelete = new System.Windows.Forms.Button();
            this.bAdd = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bSave = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.cmdfiilterBook = new System.Windows.Forms.ComboBox();
            this.dataPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.valuePannel.SuspendLayout();
            this.buttonsPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataPanel
            // 
            this.dataPanel.Controls.Add(this.dataGridView1);
            this.dataPanel.Location = new System.Drawing.Point(3, 258);
            this.dataPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataPanel.Name = "dataPanel";
            this.dataPanel.Size = new System.Drawing.Size(755, 330);
            this.dataPanel.TabIndex = 24;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.WindowFrame;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(755, 330);
            this.dataGridView1.TabIndex = 1;
            // 
            // valuePannel
            // 
            this.valuePannel.Controls.Add(this.flowLayoutPanel1);
            this.valuePannel.Controls.Add(this.idBox);
            this.valuePannel.Controls.Add(this.lnBox);
            this.valuePannel.Controls.Add(this.idnBox);
            this.valuePannel.Controls.Add(this.phoneBox);
            this.valuePannel.Controls.Add(this.label6);
            this.valuePannel.Controls.Add(this.emailBox);
            this.valuePannel.Controls.Add(this.fnBox);
            this.valuePannel.Controls.Add(this.label5);
            this.valuePannel.Controls.Add(this.label2);
            this.valuePannel.Controls.Add(this.label4);
            this.valuePannel.Controls.Add(this.label1);
            this.valuePannel.Controls.Add(this.label3);
            this.valuePannel.Location = new System.Drawing.Point(0, 86);
            this.valuePannel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.valuePannel.Name = "valuePannel";
            this.valuePannel.Size = new System.Drawing.Size(755, 168);
            this.valuePannel.TabIndex = 23;
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Location = new System.Drawing.Point(11, 355);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(7, 6);
            this.flowLayoutPanel1.TabIndex = 21;
            // 
            // idBox
            // 
            this.idBox.Location = new System.Drawing.Point(140, 15);
            this.idBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.idBox.Multiline = true;
            this.idBox.Name = "idBox";
            this.idBox.Size = new System.Drawing.Size(200, 30);
            this.idBox.TabIndex = 0;
            // 
            // lnBox
            // 
            this.lnBox.Location = new System.Drawing.Point(531, 71);
            this.lnBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lnBox.Multiline = true;
            this.lnBox.Name = "lnBox";
            this.lnBox.Size = new System.Drawing.Size(200, 30);
            this.lnBox.TabIndex = 3;
            // 
            // idnBox
            // 
            this.idnBox.Location = new System.Drawing.Point(531, 18);
            this.idnBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.idnBox.Multiline = true;
            this.idnBox.Name = "idnBox";
            this.idnBox.Size = new System.Drawing.Size(200, 30);
            this.idnBox.TabIndex = 4;
            // 
            // phoneBox
            // 
            this.phoneBox.Location = new System.Drawing.Point(531, 119);
            this.phoneBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.phoneBox.Multiline = true;
            this.phoneBox.Name = "phoneBox";
            this.phoneBox.Size = new System.Drawing.Size(200, 30);
            this.phoneBox.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(425, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = " Last Name ";
            // 
            // emailBox
            // 
            this.emailBox.Location = new System.Drawing.Point(140, 122);
            this.emailBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.emailBox.Multiline = true;
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(200, 30);
            this.emailBox.TabIndex = 6;
            // 
            // fnBox
            // 
            this.fnBox.Location = new System.Drawing.Point(140, 69);
            this.fnBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fnBox.Multiline = true;
            this.fnBox.Name = "fnBox";
            this.fnBox.Size = new System.Drawing.Size(200, 30);
            this.fnBox.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(394, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = " Identity Number ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(101, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(19, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Id";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(398, 122);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = " Phone Number ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(40, 71);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = " First Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(70, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = " Email ";
            // 
            // buttonsPanel
            // 
            this.buttonsPanel.Controls.Add(this.button1);
            this.buttonsPanel.Controls.Add(this.bDelete);
            this.buttonsPanel.Controls.Add(this.bAdd);
            this.buttonsPanel.Location = new System.Drawing.Point(104, 603);
            this.buttonsPanel.Name = "buttonsPanel";
            this.buttonsPanel.Size = new System.Drawing.Size(554, 81);
            this.buttonsPanel.TabIndex = 22;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Dock = System.Windows.Forms.DockStyle.Right;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Image = global::LaiblaryHM.Properties.Resources.icons8_save_30;
            this.button1.Location = new System.Drawing.Point(439, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(115, 81);
            this.button1.TabIndex = 12;
            this.button1.Text = "Save";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bDelete
            // 
            this.bDelete.BackColor = System.Drawing.Color.Red;
            this.bDelete.FlatAppearance.BorderSize = 0;
            this.bDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bDelete.Image = global::LaiblaryHM.Properties.Resources.icons8_delete_30;
            this.bDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bDelete.Location = new System.Drawing.Point(223, 0);
            this.bDelete.Name = "bDelete";
            this.bDelete.Size = new System.Drawing.Size(115, 81);
            this.bDelete.TabIndex = 10;
            this.bDelete.Text = " Delete";
            this.bDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bDelete.UseVisualStyleBackColor = false;
            this.bDelete.Click += new System.EventHandler(this.bDelete_Click);
            // 
            // bAdd
            // 
            this.bAdd.BackColor = System.Drawing.Color.Goldenrod;
            this.bAdd.Dock = System.Windows.Forms.DockStyle.Left;
            this.bAdd.FlatAppearance.BorderSize = 0;
            this.bAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bAdd.Image = global::LaiblaryHM.Properties.Resources.icons8_plus_math_30;
            this.bAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bAdd.Location = new System.Drawing.Point(0, 0);
            this.bAdd.Name = "bAdd";
            this.bAdd.Size = new System.Drawing.Size(115, 81);
            this.bAdd.TabIndex = 9;
            this.bAdd.Text = "Add";
            this.bAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bAdd.UseVisualStyleBackColor = false;
            this.bAdd.Click += new System.EventHandler(this.bAdd_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bSave);
            this.panel1.Controls.Add(this.searchBox);
            this.panel1.Controls.Add(this.cmdfiilterBook);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(755, 81);
            this.panel1.TabIndex = 25;
            // 
            // bSave
            // 
            this.bSave.BackColor = System.Drawing.Color.Orange;
            this.bSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSave.Image = global::LaiblaryHM.Properties.Resources.icons8_search_24;
            this.bSave.Location = new System.Drawing.Point(591, 20);
            this.bSave.Name = "bSave";
            this.bSave.Size = new System.Drawing.Size(115, 40);
            this.bSave.TabIndex = 18;
            this.bSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bSave.UseVisualStyleBackColor = false;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // searchBox
            // 
            this.searchBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBox.Location = new System.Drawing.Point(360, 20);
            this.searchBox.Multiline = true;
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(234, 38);
            this.searchBox.TabIndex = 17;
            this.searchBox.Text = "Search";
            this.searchBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.searchBox.Click += new System.EventHandler(this.searchBox_Click);
            // 
            // cmdfiilterBook
            // 
            this.cmdfiilterBook.BackColor = System.Drawing.Color.White;
            this.cmdfiilterBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmdfiilterBook.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdfiilterBook.FormattingEnabled = true;
            this.cmdfiilterBook.Items.AddRange(new object[] {
            " Id ",
            " Identity Number ",
            " First Name",
            " Last Name ",
            " Email ",
            " Phone Number "});
            this.cmdfiilterBook.Location = new System.Drawing.Point(54, 20);
            this.cmdfiilterBook.Name = "cmdfiilterBook";
            this.cmdfiilterBook.Size = new System.Drawing.Size(285, 37);
            this.cmdfiilterBook.TabIndex = 16;
            this.cmdfiilterBook.Text = "Fillter By";
            // 
            // ClientControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataPanel);
            this.Controls.Add(this.valuePannel);
            this.Controls.Add(this.buttonsPanel);
            this.Name = "ClientControl";
            this.Size = new System.Drawing.Size(755, 687);
            this.dataPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.valuePannel.ResumeLayout(false);
            this.valuePannel.PerformLayout();
            this.buttonsPanel.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel dataPanel;
        private System.Windows.Forms.Panel valuePannel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TextBox idBox;
        private System.Windows.Forms.TextBox lnBox;
        private System.Windows.Forms.TextBox idnBox;
        private System.Windows.Forms.TextBox phoneBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.TextBox fnBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel buttonsPanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bDelete;
        private System.Windows.Forms.Button bAdd;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.ComboBox cmdfiilterBook;
        private System.Windows.Forms.DataGridView dataGridView1;
    }
}
