﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibraryEntities;
using LibraryLogic;

namespace LaiblaryHM
{
    public partial class ReturningControl : UserControl
    {
        public ReturningControl()
        {
            InitializeComponent();
            dataGridView1.DataSource =Library.Borowings;
        }

        private void ReturningControl_Load(object sender, EventArgs e)
        {

        }

        private void bSave_Click(object sender, EventArgs e)
        {
            var selectedfillter = cmdfiilterBoorow.SelectedIndex;
            List<Borowing> dateQuerry = new List<Borowing>();
            switch (selectedfillter)
            {
                case 0:
                    dateQuerry = dateQuerry = Library.Borowings.Where(Borow => (DateTime.Now - Borow.DueReturningDate).TotalDays >= int.Parse(searchBox.Text)).ToList();
                    break;
                case 1:
                    dateQuerry = dateQuerry = Library.Borowings.Where(Borow => (12 * (DateTime.Now.Year - Borow.DueReturningDate.Year) + DateTime.Now.Month - Borow.DueReturningDate.Month >= int.Parse(searchBox.Text))).ToList();
                    break;

                case 2:
                    dateQuerry = dateQuerry = Library.Borowings.Where(Borow => (DateTime.Now.Year - Borow.DueReturningDate.Year) >= int.Parse(searchBox.Text)).ToList();
                    break;

                default:
                    MessageBox.Show("Choose fillter");
                    break;
            }
            dataGridView1.DataSource = dateQuerry;
        }
    }
}
